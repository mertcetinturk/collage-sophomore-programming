#!/usr/bin/env python
# coding: utf-8

# In[1]:


import math

def xyz2blh():
    
    x = float(input("Enter The Value For X: "))
    y = float(input("Enter The Value For Y: "))
    z = float(input("Enter The Value For Z: "))
    
    cartesian = [x,y,z]
    
    print("-----------------------\nCartesian Coordinates ----> ", cartesian)
    
    a = 6378137.0
    b = 6356752.3141
    
    e_square = (pow(a,2) - pow(b,2)) / pow(a,2)
    
    h = 0
    N = 1
    change_fi = 1

    b = math.atan(abs(z) / (math.sqrt(pow(abs(x),2) + pow(abs(y),2)))) * pow(1 - e_square*(abs(N)/(abs(N)+h)),-1) # b fonksiyonu
    
    h = (math.sqrt(pow(abs(math.degrees(x)),2) + pow(abs(math.degrees(y)),2)) / math.cos(b)) - abs(N) # h fonsiyonu 
    
    l = math.atan(abs(x)/abs(y)) # lambda fonksiyonu
    
    while change_fi < pow(10,-12):
        
        prevb = b
        
        b = math.atan(abs(z) / (math.sqrt(pow(abs(x),2) + pow(abs(y),2)))) * pow(1 - e_square*(abs(N)/(abs(N)+h)),-1)
        
        change_fi = b - prevb
        
        N = (a / math.sqrt((1 - e_square * pow(math.sin(b),2))))
    
        h = (math.sqrt(pow(abs(math.degrees(x)),2) + pow(abs(math.degrees(y)),2)) / math.cos(b)) - abs(N)
    
        l = math.atan(abs(x)/abs(y))
        
    b = math.degrees(b)
      
    l = math.degrees(l)
        
    print("-----------------------\nElipsoidal Coordinates:\nφ = {}°\nh = {} m\nλ = {}°".format(b,h,l))
    
xyz2blh()
    


# In[ ]:




